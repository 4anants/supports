-- AlterTable
ALTER TABLE "InventoryLog" ADD COLUMN "performedBy" TEXT;
